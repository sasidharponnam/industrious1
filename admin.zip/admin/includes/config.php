
<?php 


$host = "localhost";
$username = "root";
$pass = "root";
$con = mysqli_connect($host, $username, $pass, "diamond");
	// mysql_connect("localhost","root","");
	// mysql_select_db("diamond");
	
?>