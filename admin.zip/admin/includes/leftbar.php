<div class="left-sidebar bg-black-300 box-shadow ">
    <div class="sidebar-content">
        <div class="user-info closed">
            <img src="http://placehold.it/90/c2c2c2?text=User" alt="Vatsal Bhalodi" class="img-circle profile-img">
            <h6 class="title"></h6>
            <small class="info">PHP Developer</small>
        </div>
        <!-- /.user-info -->

        <div class="sidebar-nav">
            <ul class="side-nav color-gray">
                <li class="nav-header">
                    <span class="">Main Category</span>
                </li>
                <li>
                    <a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span> </a>

                </li>

                <li class="nav-header">
                    <span class="">Appearance</span>
                </li>
                <li class="has-children">
                    <a href="#"><i class="fa fa-file-text"></i> <span>Gallery</span> <i
                            class="fa fa-angle-right arrow"></i></a>
                    <ul class="child-nav">
                        <li><a href="add-img.php"><i class="fa fa-bars"></i> <span>Add image</span></a></li>
                        <li><a href="update-img.php"><i class="fa fa-bars"></i> <span>Update image</span></a></li>


                    </ul>
                </li>

                <li class="has-children">
                    <a href="#"><i class="fa fa-file-text"></i> <span>Events</span> <i
                            class="fa fa-angle-right arrow"></i></a>
                    <ul class="child-nav">
                        <li><a href="add-event.php"><i class="fa fa-bars"></i> <span>Add Event</span></a></li>



                    </ul>
                </li>
                <li class="has-children">
                    <a href="#"><i class="fa fa-file-text"></i> <span>Add Diamond</span> <i
                            class="fa fa-angle-right arrow"></i></a>
                    <ul class="child-nav">
                        <li><a href="add-diamond.php"><i class="fa fa-bars"></i> <span>Add New</span></a></li>
                    </ul>
                </li>



        </div>
        <!-- /.sidebar-nav -->
    </div>
    <!-- /.sidebar-content -->
</div>